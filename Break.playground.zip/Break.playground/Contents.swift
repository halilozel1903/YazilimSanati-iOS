import UIKit

for i in 1 ... 10{
    
    if(i == 5){
        break
    }
    
    print(i)
}
